package vn.iotstar.baitap035

data class SongModel(
    val mCode: String,
    val mTitle: String,
    val mLyric: String,
    val mArtist: String
)