package vn.iotstar.baitap035

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface

class MainActivity : ComponentActivity() {
    private val mSongs = listOf(
        SongModel("60696", "NẾU EM CÒN TỒN TẠI", "Khi anh bắt đầu 1 tình yêu Là lúc anh tự thay", "Trịnh Đình Quang"),
        SongModel("60701", "NGỐC", "Có rất nhiều những câu chuyện Em dấu riêng mình em biết", "Khắc Việt"),
        SongModel("60850", "HÃY TIN ANH LẦN NỮA", "Dẫu cho ta đã sai khi để bên nhau Cô yêu thương", "Thiên Dũng"),
        SongModel("60610", "CHUỖI NGÀY VẮNG EM", "Từ khi em bước ra đi cõi lòng anh ngập tràng bao", "Duy Cường"),
        SongModel("60856", "KHI NGƯỜI MÌNH YÊU KHÓC", "Nước mắt em đang rơi trên những ngón tay Nước mắt em", "Phạm Mạnh Quỳnh"),
        SongModel("60857", "VÌ ANH THƯƠNG EM", "Anh mở gặp em anh mở được ôm anh mở được gần", "Trịnh Thăng Bình"),
        SongModel("60752", "TÌNH YÊU CHẮP VÁ", "Muốn đi xa nơi yêu thương mình từng có Để không nghe", "Mr. Siro"),
        SongModel("60855", "CHỜ NGÀY MƯA TAN", "1 ngày mưa em khuất xa nơi anh bóng dáng cũ", "Trung Đức"),
        SongModel("60733", "CÂU HỎI EM CHƯA TRẢ LỜI", "Cần nói em 1 lời giãi thích thật lòng Đừng lặng im", "Yuki Huy Nam"),
        SongModel("60863", "QUA LẦNG LẼ", "Đôi khi đến với nhau yêu thương chẳng được lâu nhưng khi", "Phan Mạnh Quỳnh"),
        SongModel("60856", "QUÊN ANH LÀ ĐIỀU EM KHÔNG THỂ - REMIX", "Cần thêm bao lâu để em quên đi niềm đau Cần thêm", "Thiện Ngôn")
    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface {
                    SongListScreen(songs = mSongs)
                }
            }
        }
    }
}